package org.mewx.projectprpr.reader.setting;

/**
 * Created by MewX on 04/30/2016.
 */
public class ReaderSaveBasic { // deprecated
    public String aid;
    public String vid;
    public String cid;
    public int lineId;
    public int wordId;
}
