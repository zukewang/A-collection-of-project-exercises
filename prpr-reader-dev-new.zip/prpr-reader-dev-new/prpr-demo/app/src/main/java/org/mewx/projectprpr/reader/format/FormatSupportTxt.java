package org.mewx.projectprpr.reader.format;

/**
 * Novel format support for ".txt".
 * Created by MewX on 3/31/2016.
 */
public class FormatSupportTxt {
}
