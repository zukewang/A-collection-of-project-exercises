package org.mewx.projectprpr.activity;

import org.mewx.projectprpr.template.AppCompatTemplateActivity;

/**
 * Created by MewX on 4/14/2016.
 * Call by NovelDataSourceBasic to fetch data.
 */
public class DataSourceItemNovelListActivity extends AppCompatTemplateActivity {
}
