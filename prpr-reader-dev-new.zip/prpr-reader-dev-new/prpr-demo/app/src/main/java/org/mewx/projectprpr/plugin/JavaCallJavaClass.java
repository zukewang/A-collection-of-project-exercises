package org.mewx.projectprpr.plugin;

/**
 * This class is a loader! Contains the functions that load dex-plugins.
 * The class in dex should extend from this class.
 * todo: generate class from pluginInfo
 * Created by MewX on 1/19/2016.
 */
public abstract class JavaCallJavaClass {
    private static final String TAG = JavaCallJavaClass.class.getSimpleName();

    JavaCallJavaClass(String path) {

    }
}
