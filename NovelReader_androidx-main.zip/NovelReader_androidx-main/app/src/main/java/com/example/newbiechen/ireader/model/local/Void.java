package com.example.newbiechen.ireader.model.local;

/**
 * Created by newbiechen on 17-5-27.
 */

public final class Void {
}
