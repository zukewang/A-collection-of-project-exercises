package com.kunfei.bookshelf.help.permission

interface OnPermissionsGrantedCallback {

    fun onPermissionsGranted(requestCode: Int)

}
