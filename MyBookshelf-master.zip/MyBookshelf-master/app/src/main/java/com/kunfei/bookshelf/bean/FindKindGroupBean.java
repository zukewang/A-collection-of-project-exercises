package com.kunfei.bookshelf.bean;

public class FindKindGroupBean {
    private String groupName;
    private String groupTag;

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupTag() {
        return groupTag;
    }

    public void setGroupTag(String groupTag) {
        this.groupTag = groupTag;
    }

}
