package com.kunfei.bookshelf.widget.recycler.refresh;

public interface BaseRefreshListener {

    public void startRefresh();
}
