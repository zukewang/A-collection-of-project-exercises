package com.kunfei.bookshelf.widget.recycler.expandable.bean;

/**
 * author：Drawthink
 * describe:
 * date: 2017/5/22
 */

public abstract class BaseItem {

    public abstract boolean isParent();

//    public abstract boolean isExpand();
}
