package com.kunfei.bookshelf.constant;

public class BookType {
    public final static String AUDIO = "AUDIO";
}
