package org.mewx.wenku8.listener;

import android.view.View;

// declare the long click interface
public interface MyItemLongClickListener {
    void onItemLongClick(View view,int position);
}
