package org.mewx.wenku8.listener;

import android.view.View;

// declare the click interface
public interface MyItemClickListener {
    void onItemClick(View view,int position);
}
