package org.mewx.wenku8.global.api;

import java.io.Serializable;

/**
 * Created by MewX on 2015/5/13.
 * Chapter Info.
 */
public class ChapterInfo implements Serializable {
    public int cid;
    public String chapterName;
}
