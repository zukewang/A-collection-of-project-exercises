package com.zhao.myreader.ui.home.bbs;

import android.content.Context;

import androidx.lifecycle.Lifecycle;

import com.zhao.myreader.base.BasePresenter;

/**
 * Created by zhao on 2017/7/25.
 */

public class BBSPrensenter extends BasePresenter {

    public BBSPrensenter(Context context, Lifecycle lifecycle) {
        super(context, lifecycle);
    }

    @Override
    public void create() {

    }
}
