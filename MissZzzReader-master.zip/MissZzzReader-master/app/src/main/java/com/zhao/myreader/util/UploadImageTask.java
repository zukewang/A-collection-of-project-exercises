package com.zhao.myreader.util;

/**
 * Created by Administrator on 2016/12/28.
 */

public class UploadImageTask{
}
