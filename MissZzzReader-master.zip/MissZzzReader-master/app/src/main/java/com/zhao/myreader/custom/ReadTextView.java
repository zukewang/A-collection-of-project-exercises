package com.zhao.myreader.custom;

import android.content.Context;

import androidx.appcompat.widget.AppCompatTextView;


/**
 * Created by zhao on 2017/8/16.
 */

public class ReadTextView extends AppCompatTextView {

    public ReadTextView(Context context){
        super(context);
    }
}
