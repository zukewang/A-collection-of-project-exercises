package com.zhao.myreader.common;

/**
 * Created by Administrator on 2017/1/9.
 */

public interface Common {

    int SUCCESS = 1;
    int INSUCCESS = 0;
    int LOGINEXIT = 2;
    int MESSAGE_HINT = 3;
}
