package com.zhao.myreader.callback;

/**
 * Created by zhao on 2016/4/16.
 */
public interface URLConnectionCallback {
    void onFinish(boolean checked);

}
